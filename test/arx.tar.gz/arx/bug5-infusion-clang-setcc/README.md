~/git/cba/coverage/exp250-out/infusion-clang/bintraces/o3/0x401fd9-setCC-SET0
runs indefinitely..
