0x400ac6-setCC-SET0 /home/taejoon/git/cba/coverage/tools/binary-mutator/test/infusion-gcc/suites/splitted/tc_0099.csv tc_0099_trace.csv

