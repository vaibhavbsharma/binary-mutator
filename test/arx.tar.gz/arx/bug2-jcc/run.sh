0x400c3f-jCC-CT /home/taejoon/git/cba/coverage/tools/binary-mutator/test/microwave_auto-clang2/suites/splitted/tc_0031.csv hi.csv
#/home/taejoon/git/cba/coverage/tools/binary-mutator/test/microwave_auto-clang2/bintraces/o0/0x400c3f-jCC-CT/tc_0031_trace.csv
